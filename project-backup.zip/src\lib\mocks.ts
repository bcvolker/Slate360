export const mockRevitUpload = async () => {
  console.log("Mock API: Uploading to Revit...");
  return { success: true };
};

export const mockGeneratePdfReport = async () => {
  console.log("Mock API: Generating PDF...");
  return { success: true };
};
