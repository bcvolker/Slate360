export default function SubscribePage() {
  return (
    <div className="container mx-auto py-12">
      <h1 className="text-4xl font-bold">Subscribe</h1>
      <p className="mt-4 text-muted-foreground">This is a placeholder page.</p>
    </div>
  );
}
